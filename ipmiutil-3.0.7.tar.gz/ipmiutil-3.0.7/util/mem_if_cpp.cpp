// mem_if_cpp.cpp
//    Include the actual mem_if source into this .cpp file.
//    This is a wrapper for build.exe to detect its type as C++.
//
#include "mem_if.c"
