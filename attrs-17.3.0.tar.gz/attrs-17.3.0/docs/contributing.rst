.. _contributing:

.. include:: ../CONTRIBUTING.rst

.. include:: ../CODE_OF_CONDUCT.rst
