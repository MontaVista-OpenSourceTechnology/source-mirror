Example test files for FIPS 186-2 RSA

1. The files with extension '.rsp' are response files in the proper format for CAVS validation.

2. The file SigGenRSA_186-2.txt contains values for X9.31RSA signature generation with the additional value d added to the file for testing purposes.

3.  The file SigGen15_186-2.txt contains values for RSA PKCS#1 Ver 1.5 signature geenration with the additional value d added to the file for testing purposes.

4.  The file SigGenPSS_186-2.txt contains values for RSA PKCS#1 RSASSA-PSS signature generation with the additional value d and Saltvalue added to the file for testing purposes.