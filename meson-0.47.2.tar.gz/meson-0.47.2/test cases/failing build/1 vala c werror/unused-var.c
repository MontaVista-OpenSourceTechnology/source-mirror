#warning "something"

int
somelib(void)
{
  int unused_var;
  return 33;
}
