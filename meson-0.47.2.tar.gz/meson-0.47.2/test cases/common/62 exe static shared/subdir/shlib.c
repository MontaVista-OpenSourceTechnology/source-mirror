#include "exports.h"

int DLL_PUBLIC shlibfunc() {
    return 42;
}
