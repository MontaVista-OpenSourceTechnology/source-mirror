#include"generated.h"

int main(int argc, char **argv) {
    return THE_NUMBER != 9;
}
