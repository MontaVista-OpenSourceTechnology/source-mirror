#define BUILDING_DLL

#include<mylib.h>

int func2() {
    return 42;
}
