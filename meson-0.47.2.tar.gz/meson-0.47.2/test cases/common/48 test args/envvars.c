#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main(int argc, char **argv) {
    if(strcmp(getenv("first"), "val1") != 0) {
        fprintf(stderr, "First envvar is wrong. %s\n", getenv("first"));
        return 1;
    }
    if(strcmp(getenv("second"), "val2") != 0) {
        fprintf(stderr, "Second envvar is wrong.\n");
        return 1;
    }
    if(strcmp(getenv("third"), "val3:and_more") != 0) {
        fprintf(stderr, "Third envvar is wrong.\n");
        return 1;
    }
    if(strstr(getenv("PATH"), "fakepath:") != NULL) {
        fprintf(stderr, "Third envvar is wrong.\n");
        return 1;
    }
    return 0;
}
