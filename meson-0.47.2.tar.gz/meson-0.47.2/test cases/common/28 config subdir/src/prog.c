#include "config.h"

int main(int argc, char **argv) {
    return RETURN_VALUE;
}
