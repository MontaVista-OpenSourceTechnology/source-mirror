#ifndef PROJECT_OPTION
#error
#endif

#ifndef PROJECT_OPTION_1
#error
#endif

#ifndef GLOBAL_ARGUMENT
#error
#endif

#ifdef SUBPROJECT_OPTION
#error
#endif

#ifdef OPTION_CPP
#error
#endif

#ifndef PROJECT_OPTION_C_CPP
#error
#endif

int main(int argc, char **argv) {
    return 0;
}
