#include<nonexisting.h>
void func() { printf("This won't work.\n"); }
