#include<stdio.h>
void func() { printf("Something.\n"); }
