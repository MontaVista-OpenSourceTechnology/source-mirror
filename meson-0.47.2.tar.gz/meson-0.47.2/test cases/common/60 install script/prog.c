#include<stdio.h>

int main(int argc, char **argv) {
    printf("This is text.\n");
    return 0;
}
