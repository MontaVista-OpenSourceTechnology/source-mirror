#include"extractor.h"

int func2() {
    return 2;
}
