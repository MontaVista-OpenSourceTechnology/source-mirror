#include<proj1.h>
#include<stdio.h>

void proj1_func1() {
    printf("In proj1_func1.\n");
}
