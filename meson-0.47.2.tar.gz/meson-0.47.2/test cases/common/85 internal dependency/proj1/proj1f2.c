#include<proj1.h>
#include<stdio.h>

void proj1_func2() {
    printf("In proj1_func2.\n");
}
