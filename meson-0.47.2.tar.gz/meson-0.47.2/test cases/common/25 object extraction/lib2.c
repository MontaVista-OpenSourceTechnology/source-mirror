int retval() {
  return 43;
}
