int func() {
    return 42;
}
