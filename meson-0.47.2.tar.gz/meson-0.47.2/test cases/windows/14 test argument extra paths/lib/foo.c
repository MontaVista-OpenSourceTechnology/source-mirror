#include "foo.h"

int
foo_process(void) {
  return 42;
}
