#include<windows.h>

class Foo;

int main(int argc, char **argv) {
    return 0;
}
