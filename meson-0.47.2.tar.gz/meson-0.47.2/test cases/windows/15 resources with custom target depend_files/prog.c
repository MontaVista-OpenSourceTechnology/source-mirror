#include<windows.h>

#define MY_ICON 1

int APIENTRY
WinMain(
    HINSTANCE hInstance,
    HINSTANCE hPrevInstance,
    LPSTR lpszCmdLine,
    int nCmdShow) {
    HICON hIcon;
    hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(MY_ICON));
    return hIcon ? 0 : 1;
}
