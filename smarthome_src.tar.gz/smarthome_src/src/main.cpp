#include <QtQuick/QQuickView>
#include <QGuiApplication>

#include "myquickview.h"

Q_DECL_EXPORT int main(int argc, char *argv[])
{

    QGuiApplication app(argc, argv);

    MyQuickView viewer;
    //viewer.setOrientation(QQuickView::ScreenOrientationAuto);
    viewer.setSource(QUrl("qml/smarthome/smarthome.qml"));

    QObject::connect((QObject*)viewer.engine(), SIGNAL(quit()), &app, SLOT(quit()));

    viewer.resize(800, 480);
    viewer.setResizeMode(QQuickView::SizeRootObjectToView);

    viewer.show();

    return app.exec();
}
