#include <rdma/ib_verbs.h>

void foo(void) { }
