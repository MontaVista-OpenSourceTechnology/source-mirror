
$l2h_cache_key = q/T\'et/;
$l2h_cache{$l2h_cache_key} = q|T&#233;t|;
1;