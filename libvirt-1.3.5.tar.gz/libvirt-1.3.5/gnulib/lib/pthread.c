#include <config.h>
#define _GL_PTHREAD_INLINE _GL_EXTERN_INLINE
#include "pthread.h"
typedef int dummy;
