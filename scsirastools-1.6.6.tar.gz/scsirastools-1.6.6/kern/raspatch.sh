#!/bin/sh
# apply scsiras patches to a 2.4.18 kernel
#kdir=/usr/src/linux-2.4.18
kdir=`pwd`
pdir=/mnt/pub/sg/src/kern
cd $kdir
cat $pdir/aic_misc.patch    |patch -p1
cat $pdir/aic_overrun.patch |patch -p1
cat $pdir/aic_evlog.patch   |patch -p1
cat $pdir/raid_validate.patch |patch -p1
cat $pdir/raid_null.patch     |patch -p1
cat $pdir/raid_evlog.patch    |patch -p1
cat $pdir/scsi_rescan.patch |patch -p1
cat $pdir/scsi_ras.patch    |patch -p1
cat $pdir/scsi_reset.patch  |patch -p1
cat $pdir/scsi_evlog.patch  |patch -p1
cat $pdir/aic79_overrun.patch |patch -p1
cat $pdir/raid_oops.patch   |patch -p1
cat $pdir/raid_resync.patch |patch -p1
