# 
pdir=/mnt/pub/sg/src/kern/2.4.19
kdir=/usr/src/linux-2.4.19
kdir=`pwd`

cd $kdir
cat $pdir/aic_misc.patch    | patch -p1
cat $pdir/aic_overrun.patch | patch -p1
cat $pdir/aic_evlog.patch   | patch -p1
cat $pdir/raid_validate.patch | patch -p1
cat $pdir/raid_null.patch   | patch -p1
cat $pdir/raid_evlog.patch  | patch -p1
cat $pdir/scsi_rescan.patch | patch -p1
cat $pdir/scsi_ras.patch    | patch -p1
# cat $pdir/scsi_reset.patch  | patch -p1  # already there in 2.4.19
cat $pdir/scsi_evlog.patch  | patch -p1
