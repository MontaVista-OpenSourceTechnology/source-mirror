autoconf
aclocal
automake
