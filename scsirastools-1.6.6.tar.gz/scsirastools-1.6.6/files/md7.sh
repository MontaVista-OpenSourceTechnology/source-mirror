#--------------------------------------------------------
# Script 7 to mount the raid partitions
if [ -d /dev/md ]
then
  mdev=/dev/md/
else 
  mdev=/dev/md
fi
mkdir -p /mnt/b
mount -t ext2 ${mdev}0 /mnt/b
mkdir -p /mnt/b/boot
mount -t ext2 ${mdev}1 /mnt/b/boot 
# end script 7
#--------------------------------------------------------
