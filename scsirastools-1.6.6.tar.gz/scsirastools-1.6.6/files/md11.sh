#--------------------------------------------------------
# Script 11 - edit the lilo files to boot to md0
kver=`uname -r`
tmpe1=/tmp/ed1
tmpe2=/tmp/ed2
lilo1=/etc/lilo.conf
lilo2=/mnt/b/etc/lilo.conf
devm=/dev/md
initrdmsg="initrd=/boot/initrd-${kver}.img"
if [ -d /dev/scsi/host0 ]
then
	# DevFS sample for MV CGE 3.0
	devm=/dev/md/
	ktag=`uname -r |cut -f2 -d'-'`
	kver="intel-${ktag}"
	initrdmsg=""
fi
cat - <<%%% >$tmpe1
H
$
a
 
image=/boot/vmlinuz-${kver}
        label=linux-md0
        root=${devm}0
        $initrdmsg
        read-only
.
w
q
%%%
cat - <<%%% >$tmpe2
H
1
/boot=
c
boot=${devm}1
.
/default=
c
default=linux-md0
.
$
a

image=/boot/vmlinuz-${kver}
        label=linux-md0
        root=${devm}0
        $initrdmsg
        read-only
.
w
q
%%%
ed  $lilo1 <$tmpe1
ed  $lilo2 <$tmpe2
# completely different for grub
# end script 11
#--------------------------------------------------------
