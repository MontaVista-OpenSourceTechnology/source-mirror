#--------------------------------------------------------
# Script 8 to copy Linux files to mounted tree
todir=/mnt/b
notf=/tmp/dirnot.tmp
cat - <<%%% >$notf
tmp
proc
mnt
boot
lost+found
media
sys
%%%
# dirs="bin dev etc home lib misc opt root sbin usr var"
dirs=`ls / |grep -vf $notf`
cd /
# Copy each directory in the list
# could use "find . -print | cpio -pdumv" if grep -v extra stuff. 
for d in $dirs
do
    echo "Copying $d to $todir/$d..."
    cp -a $d $todir
done
# Do /tmp, /proc, /mnt, and /boot specially
echo "Creating $todir/tmp, mnt, proc..."
mkdir -p $todir/tmp  
chmod 777 $todir/tmp
chmod +t $todir/tmp
mkdir -p $todir/proc
# makes /mnt directories like cdrom and floppy
for i in `ls -l /mnt |grep "^dr" |cut -c57-80`
do
    mkdir -p $todir/mnt/$i
done
if [ -f /etc/SuSE-release ]
then
    mkdir -p $todir/media/cdrom
    mkdir -p $todir/media/floppy
    mkdir -p $todir/sys
fi
echo "Copying boot to $todir/boot..."
cd /boot
find . -print |cpio -pdumv $todir/boot 2>/dev/null
# This will usually give an "omitting lost+found" stderr message.   
# end script 8
#--------------------------------------------------------
