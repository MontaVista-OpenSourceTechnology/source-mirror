#--------------------------------------------------------
# Script 1 - md1.sh
# Make sure the system was installed with raidtools
rpm -qa |grep  raidtools
if [ $? -eq 0 ]
then
   echo "OK, continue"
   echo ""
else
   echo "Error: raidtools should be installed."
   exit 1
fi

exit 0
# end script 1
#--------------------------------------------------------
