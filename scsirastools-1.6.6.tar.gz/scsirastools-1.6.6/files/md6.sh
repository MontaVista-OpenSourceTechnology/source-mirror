#--------------------------------------------------------
# Script 6 - example of making filesystems
if [ -d /dev/md ]
then
  mdev=/dev/md/
else 
  mdev=/dev/md
fi
mke2fs ${mdev}0
mke2fs ${mdev}1
mkswap ${mdev}2
swapon -a      
# end script 6
#--------------------------------------------------------
