#--------------------------------------------------------
# Script 12
lilo                                  # run lilo sda version
lilo -C /mnt/b/etc/lilo.conf          # run lilo md0 version from sdb
# different for grub
# end script 12
#--------------------------------------------------------
