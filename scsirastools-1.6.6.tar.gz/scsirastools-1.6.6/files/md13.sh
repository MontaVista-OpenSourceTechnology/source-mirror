#--------------------------------------------------------
# Script 13
umount /mnt/b/boot
umount /mnt/b
if [ -d /dev/md ]
then
  swapoff  /dev/md/2
  raidstop /dev/md/2
  raidstop /dev/md/1
  raidstop /dev/md/0
else 
  swapoff  /dev/md2
  raidstop /dev/md2
  raidstop /dev/md1
  raidstop /dev/md0
fi
shutdown -r now 
# end script 13
#--------------------------------------------------------
