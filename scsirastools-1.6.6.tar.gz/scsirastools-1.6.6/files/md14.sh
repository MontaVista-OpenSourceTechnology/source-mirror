#--------------------------------------------------------
# Script 14
if [ -d /dev/scsi/host0 ]
then
deva=/dev/scsi/host1/bus0/target0/lun0/disc
devb=/dev/scsi/host1/bus0/target1/lun0/disc
else
deva=/dev/sda
devb=/dev/sdb
fi
sfdisk -d $devb  >/tmp/sdb.sfdisk
sfdisk --force $deva </tmp/sdb.sfdisk
# end script 14
#--------------------------------------------------------
