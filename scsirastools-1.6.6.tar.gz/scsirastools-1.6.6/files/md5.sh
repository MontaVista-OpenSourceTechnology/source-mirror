#--------------------------------------------------------
# Script 5 - example of setup raid partitions
if [ -d /dev/md ]
then
  mkraid -R /dev/md/0
  mkraid -R /dev/md/1
  swapoff -a           # intended to disable all swapping temporarily
  mkraid -R /dev/md/2
else 
  mkraid -R /dev/md0
  mkraid -R /dev/md1
  swapoff -a           # intended to disable all swapping temporarily
  mkraid -R /dev/md2
fi
cat /proc/mdstat   
# end script 5
#--------------------------------------------------------
