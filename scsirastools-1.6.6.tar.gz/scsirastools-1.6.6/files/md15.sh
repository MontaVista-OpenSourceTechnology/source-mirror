#--------------------------------------------------------
# Script 15
bootpart=2
rootpart=3
swappart=4
if [ -d /dev/md ]
then
deva=/dev/scsi/host1/bus0/target0/lun0/part
devb=/dev/scsi/host1/bus0/target1/lun0/part
devm=/dev/md/
else
deva=/dev/sda
devb=/dev/sdb
devm=/dev/md
fi
# This is needed for disc devs if DEVFS and is inert for other FS.
disca=`echo $deva |sed -e 's/part/disc/'`
discb=`echo $devb |sed -e 's/part/disc/'`

echo "Starting remirror to ${disca}"
sed -e 's/failed-disk/raid-disk /' /etc/raidtab >/tmp/x
cp /tmp/x /etc/raidtab
raidhotadd ${devm}1 ${deva}${bootpart}
raidhotadd ${devm}0 ${deva}${rootpart}
raidhotadd ${devm}2 ${deva}${swappart}
cat /proc/mdstat
# Run 'mdevt Save' to save sfdisk snapshot for use by sgraidmon later.
mdevt Save $discb
# May need to run lilo -M, depending on the version of lilo.  
# Also need this if errors occurred in md12.sh.
lilo -V |grep 22  >/dev/null
newlilo=$?
if [ $newlilo -eq 0 ]
then
	lilo -M $discb 
fi
# wait for bootpart recovery to run a bit
echo "waiting ..."
sleep 15
if [ $newlilo -eq 0 ]
then
	lilo -M $disca
fi
lilo 
# end script 15
#--------------------------------------------------------
