#--------------------------------------------------------
# Script 9 to modify fstab
f=/mnt/b/etc/fstab
tmp=/tmp/f
tmpe=/tmp/ed
echo "Modifying new fstab for md devices"
if [ -d /dev/md ]
then
  # DEVFS, so add another '/'
  sed -e 's/.*	\/boot	/\/dev\/md\/1	\/boot	/' -e 's/.*	\/	/\/dev\/md\/0	\/	/' -e 's/.*	swap/\/dev\/md\/2	swap/' $f >$tmp
else
  sed -e 's/.*	\/boot	/\/dev\/md1	\/boot	/' -e 's/.*	\/	/\/dev\/md0	\/	/' -e 's/.*	swap/\/dev\/md2	swap/' $f >$tmp
fi
cp $tmp $f
# end script 9
#--------------------------------------------------------
