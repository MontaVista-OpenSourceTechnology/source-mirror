/* automatically generated. DO NOT EDIT. */
#include <linux/drbd.h>
const char *drbd_buildtag(void)
{
	return "GIT-hash: c6e62702d5e4fb2cf6b3fa27e67cb0d4b399a30b"
		" build by phil@bk13-2, 2016-02-03 20:29:50";
}
