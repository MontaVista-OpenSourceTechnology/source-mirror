#define UCD_COMPATIBLE
#include <net-snmp/net-snmp-config.h>
