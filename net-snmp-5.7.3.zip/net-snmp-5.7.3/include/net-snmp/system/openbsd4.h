/* openbsd4 is a superset of openbsd3 */
#include "openbsd.h"
#define openbsd3 openbsd3
