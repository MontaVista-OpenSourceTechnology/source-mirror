#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-features.h>

netsnmp_feature_require(netsnmp_add_default_traphandler)
netsnmp_feature_require(memory_free)

