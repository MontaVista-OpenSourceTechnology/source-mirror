package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_vi_VN extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "VND", "\u0111" },
        };
    }
}
