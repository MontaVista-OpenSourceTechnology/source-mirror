package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_ko_KR extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "KRW", "\uFFE6" },
        };
    }
}
