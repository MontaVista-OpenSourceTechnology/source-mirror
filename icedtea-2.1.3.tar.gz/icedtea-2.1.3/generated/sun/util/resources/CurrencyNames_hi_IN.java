package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_hi_IN extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "INR", "\u0930\u0942" },
        };
    }
}
