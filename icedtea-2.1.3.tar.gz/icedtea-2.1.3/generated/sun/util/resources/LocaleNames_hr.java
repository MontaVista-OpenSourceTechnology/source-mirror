package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_hr extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "HR", "Hrvatska" },
            { "hr", "hrvatski" },
        };
    }
}
