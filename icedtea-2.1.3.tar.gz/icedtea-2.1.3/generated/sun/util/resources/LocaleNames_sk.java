package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_sk extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "SK", "Slovensk\u00E1 republika" },
            { "sk", "Sloven\u010Dina" },
        };
    }
}
