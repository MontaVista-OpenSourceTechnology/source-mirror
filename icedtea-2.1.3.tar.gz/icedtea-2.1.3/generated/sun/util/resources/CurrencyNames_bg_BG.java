package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_bg_BG extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "BGN", "\u043B\u0432." },
        };
    }
}
