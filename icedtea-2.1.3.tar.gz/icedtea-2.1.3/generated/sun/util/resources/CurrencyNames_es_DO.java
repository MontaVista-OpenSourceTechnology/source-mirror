package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_es_DO extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "DOP", "RD$" },
        };
    }
}
