package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_be extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "BY", "\u0411\u0435\u043B\u0430\u0440\u0443\u0441\u044C" },
            { "be", "\u0431\u0435\u043B\u0430\u0440\u0443\u0441\u043A\u0456" },
        };
    }
}
