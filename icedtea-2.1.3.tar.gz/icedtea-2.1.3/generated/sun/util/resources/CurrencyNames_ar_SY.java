package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_ar_SY extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "SYP", "\u0644.\u0633.\u200F" },
        };
    }
}
