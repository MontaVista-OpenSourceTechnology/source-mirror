package sun.util.resources;

import java.util.ListResourceBundle;

public final class CalendarData_el_CY extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "minimalDaysInFirstWeek", "1" },
        };
    }
}
