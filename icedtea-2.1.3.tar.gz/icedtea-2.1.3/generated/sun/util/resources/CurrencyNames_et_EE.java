package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_et_EE extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "EEK", "kr" },
        };
    }
}
