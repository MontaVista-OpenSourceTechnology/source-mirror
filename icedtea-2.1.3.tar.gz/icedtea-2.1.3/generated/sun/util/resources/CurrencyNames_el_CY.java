package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_el_CY extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "CYP", "\u00A3" },
            { "EUR", "\u20AC" },
        };
    }
}
