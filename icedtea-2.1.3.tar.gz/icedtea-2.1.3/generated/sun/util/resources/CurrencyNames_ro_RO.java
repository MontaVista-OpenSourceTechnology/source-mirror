package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_ro_RO extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "ROL", "LEI" },
            { "RON", "LEI" },
        };
    }
}
