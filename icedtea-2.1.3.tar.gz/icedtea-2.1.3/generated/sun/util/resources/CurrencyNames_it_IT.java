package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_it_IT extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "EUR", "\u20AC" },
            { "ITL", "L." },
        };
    }
}
