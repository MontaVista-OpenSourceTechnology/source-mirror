package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_ar_YE extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "YER", "\u0631.\u064A.\u200F" },
        };
    }
}
