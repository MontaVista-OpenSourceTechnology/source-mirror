package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_hu extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "HU", "Magyarorsz\u00E1g" },
            { "hu", "magyar" },
        };
    }
}
