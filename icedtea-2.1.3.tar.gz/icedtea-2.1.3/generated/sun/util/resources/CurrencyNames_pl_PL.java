package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_pl_PL extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "PLN", "z\u0142" },
        };
    }
}
