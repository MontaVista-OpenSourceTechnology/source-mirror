package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_pt_BR extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "AX", "Ilhas Aland" },
            { "BA", "B\u00F3snia-Herzegovina" },
            { "BH", "Bahrain" },
            { "KP", "Cor\u00E9ia do Norte" },
            { "MK", "Maced\u00F4nia" },
            { "ZW", "Zimb\u00E1bue" },
            { "ce", "checheno" },
            { "ik", "inupiaque" },
            { "jv", "javan\u00EAs" },
            { "nd", "ndebele do norte" },
            { "nr", "ndebele do sul" },
            { "st", "soto do sul" },
        };
    }
}
