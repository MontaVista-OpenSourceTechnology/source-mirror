package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_nl extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "BE", "Belgi\u00EB" },
            { "NL", "Nederland" },
            { "nl", "Nederlands" },
        };
    }
}
