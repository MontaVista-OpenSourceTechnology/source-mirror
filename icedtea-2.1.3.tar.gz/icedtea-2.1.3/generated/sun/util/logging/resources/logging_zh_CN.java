package sun.util.logging.resources;

import java.util.ListResourceBundle;

public final class logging_zh_CN extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "ALL", "\u5168\u90E8" },
            { "CONFIG", "\u914D\u7F6E" },
            { "FINE", "\u826F\u597D" },
            { "FINER", "\u8F83\u597D" },
            { "FINEST", "\u6700\u597D" },
            { "INFO", "\u4FE1\u606F" },
            { "OFF", "\u5173\u95ED" },
            { "SEVERE", "\u4E25\u91CD" },
            { "WARNING", "\u8B66\u544A" },
        };
    }
}
