package sun.util.logging.resources;

import java.util.ListResourceBundle;

public final class logging_es extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "ALL", "TODO" },
            { "CONFIG", "CONFIG" },
            { "FINE", "FINA" },
            { "FINER", "M\u00C1S FINA" },
            { "FINEST", "LA M\u00C1S FINA" },
            { "INFO", "INFO" },
            { "OFF", "APAGADO" },
            { "SEVERE", "GRAVE" },
            { "WARNING", "ADVERTENCIA" },
        };
    }
}
