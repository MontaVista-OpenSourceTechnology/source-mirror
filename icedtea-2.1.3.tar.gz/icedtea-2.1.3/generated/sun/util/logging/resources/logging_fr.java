package sun.util.logging.resources;

import java.util.ListResourceBundle;

public final class logging_fr extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "ALL", "TOUS" },
            { "CONFIG", "CONFIG" },
            { "FINE", "FIN" },
            { "FINER", "PLUS FIN" },
            { "FINEST", "LE PLUS FIN" },
            { "INFO", "INFO" },
            { "OFF", "AUCUN" },
            { "SEVERE", "GRAVE" },
            { "WARNING", "ATTENTION" },
        };
    }
}
