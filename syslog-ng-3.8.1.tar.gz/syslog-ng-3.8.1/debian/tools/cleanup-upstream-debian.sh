#! /bin/sh
set -e

rm -f README.markdown

